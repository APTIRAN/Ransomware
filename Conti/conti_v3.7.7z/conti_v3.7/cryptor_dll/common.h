#pragma once
#include <WinSock2.h>
#include <string>

#define EXE_BUILD
//#define DEBUG
#define STATIC