#pragma once

#include <WinSock2.h>

VOID DisableHooks();
VOID removeHooks(HMODULE hmodule);